package com.example.group07_hw03;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

public class AppsAdapter extends ArrayAdapter<Apps> {
    Context mContext;
    List<Apps> data;
    int mresource;
    SharedPreferences sharedPreferences;
    ArrayList<Apps> favApps;
    FavoritesActivity favoritesActivity;

    public AppsAdapter(Context context, int resource, List<Apps> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.data = objects;
        this.mresource = resource;
        favoritesActivity = null;
    }

    public AppsAdapter(Context context, int resource, List<Apps> objects, FavoritesActivity favoritesActivity) {
        super(context, resource, objects);
        this.mContext = context;
        this.data = objects;
        this.mresource = resource;
        this.favoritesActivity = favoritesActivity;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mresource, parent, false);
            holder  = new ViewHolder();
            holder.image = (ImageView) convertView.findViewById(R.id.image);
            holder.appText = (TextView) convertView.findViewById(R.id.appText);
            holder.favButton = (ImageButton) convertView.findViewById(R.id.favButton);
            convertView.setTag(holder);

        }

        final Apps app = data.get(position);


        holder = (ViewHolder) convertView.getTag();
        TextView text = holder.appText;
        ImageView image = holder.image;
        final ImageButton fav = holder.favButton;

        text.setText(app.toString());

        if(app.getImageURL() != null){
            Picasso.with(convertView.getContext()).load(app.getImageURL()).into(image);
        }

        sharedPreferences = mContext.getSharedPreferences("com.example.group07_hw03", Context.MODE_PRIVATE);

        Gson gson = new Gson();
        String json = sharedPreferences.getString("favs", "");

        if(!json.isEmpty()){
            Type type = new TypeToken<ArrayList<Apps>>() {
            }.getType();
            favApps = gson.fromJson(json, type);

            for(Apps favApp : favApps){

                if (favApp.getName().equals(app.getName())){
                    if(favApp.getFavorite()){
                        app.setFavorite(true);
                    }
                }
            }
        } else {
            favApps = new ArrayList<Apps>();
        }

        if(app.isFavorite){
            fav.setImageResource(R.drawable.blackstar);
        }else{
            fav.setImageResource(R.drawable.whitestar);
        }

        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    if (app.isFavorite) {

                        new AlertDialog.Builder(mContext).setTitle("Remove app?")
                                .setMessage("Remove this app from favorites?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        fav.setImageResource(R.drawable.whitestar);
                                        app.setFavorite(false);

                                        for (Apps a : favApps) {
                                            if (a.getName().equals(app.getName())) {
                                                favApps.remove(a);
                                                break;
                                            }
                                        }

                                        Gson gson = new Gson();
                                        String json = gson.toJson(favApps);

                                        sharedPreferences.edit().putString("favs", json).apply();
                                        if(favoritesActivity != null) {
                                            favoritesActivity.refresh();
                                        }
                                    }
                                })
                                .setNegativeButton("No", null)
                                .show();

                    } else {

                        new AlertDialog.Builder(mContext).setTitle("Add app?")
                                .setMessage("Add this app to favorites?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        fav.setImageResource(R.drawable.blackstar);
                                        app.setFavorite(true);
                                        favApps.add(app);

                                        Gson gson = new Gson();
                                        String json = gson.toJson(favApps);

                                        sharedPreferences.edit().putString("favs", json).apply();
                                    }
                                }).setNegativeButton("No", null)
                                .show();

                    }
                } catch (ConcurrentModificationException e){

                }
            }
        });






        return convertView;

    }
    static class ViewHolder{
        TextView appText;
        ImageButton favButton;
        ImageView image;


    }

    public void clearData() {
        // clear the data
        data.clear();
    }

}


