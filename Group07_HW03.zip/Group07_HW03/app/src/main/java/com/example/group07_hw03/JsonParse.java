package com.example.group07_hw03;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class JsonParse {
    public static ArrayList<Apps> parseApps(String in) throws JSONException {
        ArrayList<Apps> appList = new ArrayList<>();
        JSONObject root = new JSONObject(in);
        JSONArray appArray = root.getJSONObject("feed").getJSONArray("entry");
        for(int i = 0; i < appArray.length(); i++){
            JSONObject appJSON = appArray.getJSONObject(i);
            Apps app = new Apps();
            app.setName(appJSON.getJSONObject("title").getString("label"));
            JSONArray image = appJSON.getJSONArray("im:image");
            app.setImageURL(image.getJSONObject(0).getString("label"));
            app.setPrice(appJSON.getJSONObject("im:price").getString("label"));
            app.setCurrency(appJSON.getJSONObject("im:price").getJSONObject("attributes").getString("currency"));

            appList.add(app);

        }
        return appList;
    }
}

